namespace BelaSopa.Models.DomainModels.Assistente
{
    public enum Dificuldade
    {
        Facil,
        Media,
        Dificil
    }
}
