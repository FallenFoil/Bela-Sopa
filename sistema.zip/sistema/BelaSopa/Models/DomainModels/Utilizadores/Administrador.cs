namespace BelaSopa.Models.DomainModels.Utilizadores
{
    public class Administrador : Utilizador
    {
    }
}
